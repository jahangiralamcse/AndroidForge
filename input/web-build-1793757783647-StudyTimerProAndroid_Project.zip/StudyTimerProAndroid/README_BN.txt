Study Timer Pro Android Project

এই ZIP-এ Android Studio project দেওয়া হয়েছে। এই পরিবেশে Android SDK/Gradle build tools নেই, তাই এখানে সরাসরি APK compile করা সম্ভব হয়নি।

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP ফাইল Extract করুন।
3. Android Studio > Open > Extract করা StudyTimerPro ফোল্ডারটি নির্বাচন করুন।
4. Gradle sync শেষ হতে দিন। প্রয়োজন হলে Android SDK Platform 35 ইনস্টল করুন।
5. মেনু থেকে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
6. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk এ পাওয়া যাবে।

নোট:
- অ্যাপটি WebView-এর মধ্যে অফলাইনে থাকা HTML সফটওয়্যার চালায়।
- পড়ার সেশন localStorage-এ সংরক্ষিত হয়।
- অ্যাপ আনইনস্টল বা অ্যাপের data clear করলে সংরক্ষিত history মুছে যেতে পারে।
